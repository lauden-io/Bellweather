Bellweather brand kit
=====================

Everything for using the Bellweather name and logo. The rules are in
Bellweather-Brand-Guidelines.pdf; the short version is below.

Folders
  logo/     The logo (badge + wordmark). SVG is vector and needs no font.
            logo.svg            light grounds
            logo-dark.svg       dark grounds
            logo-reversed-white.svg   on Bellweather cobalt only
            *.png               transparent rasters, 256 and 512 px high
            logo-motto*.svg     the logo with the motto, beside the badge
            logo-motto-stacked*.svg   the same, stacked, for square spaces
            logo-motto*.png     both as transparent rasters (1x and 2x)
  badge/    The square icon: badge.svg, PNGs from 16 to 1024 px,
            favicon.ico (16, 32, 48) and apple-touch-icon.png (180).
  mark/     The open mark without the badge: colour (light / dark grounds)
            and one-colour (ink / white). Secondary; prefer the badge.
  credit/   "Weather data fused by Bellweather" badges, light and dark,
            as SVG and PNG, with embed.html (copy-paste code).
  colour/   bellweather.ase (Adobe, Affinity), bellweather.gpl (GIMP,
            Inkscape), colours.css, colours.json.
  social/   social-preview.png, 1280 x 640, for the repository and links.

Colours (screen: HEX; print: CMYK)
  Cobalt        #1F5FD6   C85 M69 Y0 K0 coated   C95 M64 Y0 K0 uncoated
  Sun           #FFB31A   C0 M36 Y92 K0 coated   C0 M21 Y100 K0 uncoated
  Ink           #0E1F3D   C95 M75 Y26 K66 coated   C100 M68 Y16 K71 uncoated
  Paper         #F3F2EE   C5 M4 Y7 K0 coated   C3 M2 Y4 K2 uncoated
  Cobalt light  #5B97FF   C64 M42 Y0 K0 coated   C61 M34 Y0 K0 uncoated
  Sun light     #FFC340   C0 M27 Y81 K0 coated   C1 M16 Y87 K1 uncoated

  Screens, web, apps, office and home printers: use HEX / RGB.
  Commercial print on coated paper: CMYK coated (ISO Coated v2, FOGRA39).
  Commercial print on uncoated paper: CMYK uncoated (PSO Uncoated).
  Send the press a PDF with the profile named; ask for a proof.

Rules in brief
  - Use the badge everywhere a square icon goes; the logo where there is room.
  - Never retype the wordmark, recolour, stretch, rotate or add effects.
  - Clear space: a quarter of the badge's height on every side.
  - Minimum size: logo badge 6 mm / 20 px high; badge 5 mm / 16 px;
    logo with the motto: badge 12 mm / 56 px high.
  - The motto is part of its artwork: never type it next to the logo.

The wordmark is artwork drawn from Outfit (SIL Open Font License 1.1).
